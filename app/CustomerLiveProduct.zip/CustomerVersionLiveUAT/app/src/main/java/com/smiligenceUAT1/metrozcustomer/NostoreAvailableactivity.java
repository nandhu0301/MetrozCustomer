package com.smiligenceUAT1.metrozcustomer;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class NostoreAvailableactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.no_stores_available);
    }


}