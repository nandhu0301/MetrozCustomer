package com.smiligenceUAT1.metrozcustomer.common;

public interface SimplePlacePicker
{
    String PACKAGE_NAME = "com.example.metrozcustomer.common";
    String RECEIVER = PACKAGE_NAME + ".RECEIVER";
    String RESULT_DATA_KEY = PACKAGE_NAME + ".RESULT_DATA_KEY";
    String LOCATION_LAT_EXTRA = PACKAGE_NAME + ".LOCATION_lAT_EXTRA";
    String LOCATION_LNG_EXTRA = PACKAGE_NAME + ".LOCATION_LNG_EXTRA";
    String SELECTED_ADDRESS = PACKAGE_NAME + ".SELECTED_ADDRESS";
    String LANGUAGE = PACKAGE_NAME + ".LANGUAGE" ;
    String API_KEY = PACKAGE_NAME + ".AIzaSyDpsvgIXk27nIS9Zivz5W3VkHue4ow3cYg";
    String COUNTRY = PACKAGE_NAME + ".COUNTRY";
    String SUPPORTED_AREAS = PACKAGE_NAME + ".SUPPORTED_AREAS";
    int SUCCESS_RESULT = 0;
    int FAILURE_RESULT = 1;

}
