package com.smiligenceUAT1.metrozcustomer.bean;

public class ContactDetails
{

        public String getWhatsAppContact() {
            return whatsAppContact;
        }

        public void setWhatsAppContact(String whatsAppContact) {
            this.whatsAppContact = whatsAppContact;
        }

        String whatsAppContact;
}
