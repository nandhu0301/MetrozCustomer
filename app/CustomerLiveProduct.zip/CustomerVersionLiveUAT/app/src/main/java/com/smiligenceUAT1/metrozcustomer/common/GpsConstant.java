package com.smiligenceUAT1.metrozcustomer.common;

public class GpsConstant
{
    public static final int BASIC_FAIR = 25;
    public static final int MINIMUM_FAIR = 35;
    public static final int PER_Km = 7;
}
