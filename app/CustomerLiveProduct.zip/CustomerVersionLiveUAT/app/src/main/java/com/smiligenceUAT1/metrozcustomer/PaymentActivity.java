package com.smiligenceUAT1.metrozcustomer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;
import com.razorpay.Checkout;
import com.razorpay.Order;
import com.razorpay.Payment;
import com.razorpay.PaymentData;
import com.razorpay.PaymentResultWithDataListener;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.smiligenceUAT1.metrozcustomer.adapter.PaymentAdapter;
import com.smiligenceUAT1.metrozcustomer.bean.CustomerDetails;
import com.smiligenceUAT1.metrozcustomer.bean.ItemDetails;
import com.smiligenceUAT1.metrozcustomer.bean.MaintainFairDetails;
import com.smiligenceUAT1.metrozcustomer.bean.MetrozStoreTime;
import com.smiligenceUAT1.metrozcustomer.bean.OrderDetails;
import com.smiligenceUAT1.metrozcustomer.bean.StoreTimings;
import com.smiligenceUAT1.metrozcustomer.common.CommonMethods;
import com.smiligenceUAT1.metrozcustomer.common.Constant;
import com.smiligenceUAT1.metrozcustomer.common.DateUtils;
import com.smiligenceUAT1.metrozcustomer.common.TextUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import cn.pedant.SweetAlert.SweetAlertDialog;

import static com.smiligenceUAT1.metrozcustomer.HomePageAcitivity.saved_id;
import static com.smiligenceUAT1.metrozcustomer.common.Constant.ORDER_DETAILS_FIREBASE_TABLE;
import static com.smiligenceUAT1.metrozcustomer.common.Constant.RAZORPAY_KEY_ID;
import static com.smiligenceUAT1.metrozcustomer.common.Constant.RAZORPAY_SECRAT_KEY;
import static com.smiligenceUAT1.metrozcustomer.common.Constant.VIEW_CART_FIREBASE_TABLE;

public class PaymentActivity extends AppCompatActivity  implements PaymentResultWithDataListener {


    DatabaseReference  distanceFeeDataRef,viewCartRef,metrozStoteTimingDataRef, oneTimeDisDataRef,storeTimingDataRef, userCurrentLocationDetails, Orderreference;
    OrderDetails orderDetails = new OrderDetails();
    ItemDetails itemDetails = new ItemDetails();
    ArrayList<ItemDetails> giftWrapItemList = new ArrayList<ItemDetails>();
    ArrayList<String> giftWappingItemList = new ArrayList<>();
    Animation animation;

    int finalBillAmount, tipsAmountInt, temp,giftWrapAmount = 0;
    ListView purchaseListView;
    ArrayList<ItemDetails> itemDetailList = new ArrayList<ItemDetails>();
    TextView totalPurchaseAmount;
    RelativeLayout purchaseLayout;
    String pattern = "hh:mm aa";
    SimpleDateFormat sdf = new SimpleDateFormat(pattern);
    String currentTime;
    DateFormat date;
    Date currentLocalTime;
    String currentDateAndTime;
    String metrozStartTime;
    String metrozStopTime;
    String amount;
    boolean checkAsync = true;
    Payment payment;
    String paymentType;
    double getStoreLatitude = 0.0, getStoreLongtitude = 0.0, roundOff = 0.0;
    CustomerDetails userCurrentLocation;
    String storeNameFromAdapter, storeId, categoryName, categoryId, pinCode;
    double sharedPreferenceLatitude = 0.0, sharedPreferenceLongtitude = 0.0;
    int getDistance;
    RazorpayClient razorpay;
    JSONObject jsonObject;
    long maxid = 0;
    String resultOrderId, receiptNumber;
    boolean checkIntent = false;
    TextView addCurrentAddressEditText;
    String deliverytType, tipAmount, finalBill_tip, finalBill, instructionString, storeAddress, getFullAdreesFromMap;
    Double latValue, longValue;
    int resultKiloMeterRoundOff = 0, totaldeliveryFee = 0, perKmDistanceFee=0,perkmDistanceFeeForDeliveryBoy=0;
    ImageView backToScreen;
    String sharedPreferenceLat, sharedPreferenceLong,customerID,addressPref,shippingAddress,customerName,customerMobilenumber,customerPinCode;
    TextView viewAddress,giftWrapText;
    TextView totalItemValue,tipValue,toPayValue;
    TextView giftText,giftAmount;
    List<String> name;
    List<Integer> id;
    TextView offerName,viewOffers;
    String testPay="";
    int getDiscountAmount=0,getMaximumBillAmount=0,ifPercentMaxAmountForDiscount=0;
    String discountName,typeOfDiscount;
    TextView deductionAmountTextView;
    String discountAppliedOrNot="No";
    int discountAmountCalculation=0;
    String getDiscountGivenBy;
    String getPreference,oneTimeOrderNumber;
    int totalFeeFordeliveryBoy;
    Integer increamentId;
    SweetAlertDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        purchaseListView = findViewById(R.id.purchaselist);
        viewAddress=findViewById(R.id.addresstext);
        totalPurchaseAmount = findViewById(R.id.totalpurchaseamountText);
        purchaseLayout = findViewById(R.id.placeorderlayout);
        totalItemValue=findViewById(R.id.itemtotalvalue);
        offerName=findViewById(R.id.discountTextview);
        viewOffers=findViewById(R.id.viewOffers);

        tipValue=findViewById(R.id.tipsvalueText);
        toPayValue=findViewById(R.id.topayvalue);
        backToScreen=findViewById(R.id.backtoScreen);
        giftWrapText = findViewById(R.id.giftavailabletext);
        animation = AnimationUtils.loadAnimation(this, R.anim.bounce);
        giftText=findViewById(R.id.giftText);
        giftAmount=findViewById(R.id.giftTextAmount);
        deductionAmountTextView=findViewById(R.id.deductionAmount);
        distanceFeeDataRef = CommonMethods.fetchFirebaseDatabaseReference("MaintainFairDetails");
        oneTimeDisDataRef = CommonMethods.fetchFirebaseDatabaseReference("OneTimeDiscount");


        storeNameFromAdapter = getIntent().getStringExtra("StoreName");
        storeId = getIntent().getStringExtra("StoreId");
        categoryName = getIntent().getStringExtra("categoryName");
        categoryId = getIntent().getStringExtra("categoryId");
        pinCode = getIntent().getStringExtra("pinCode");
        addressPref=getIntent().getStringExtra("addressPref");
        shippingAddress=getIntent().getStringExtra("shippingAddress");
        customerName=getIntent().getStringExtra("customerName");
        customerMobilenumber=getIntent().getStringExtra("customerMobilenumber");
        customerPinCode=getIntent().getStringExtra("customerPinCode");
        deliverytType = getIntent().getStringExtra("deliveryType");
        tipAmount = getIntent().getStringExtra("tips");
        finalBill_tip = getIntent().getStringExtra("finalBillTip");
        finalBill = getIntent().getStringExtra("finalBillAmount");
        instructionString = getIntent().getStringExtra("instructionString");
        storeAddress = getIntent().getStringExtra("storeAddress");
        getFullAdreesFromMap = getIntent().getStringExtra("FullAddress");
        latValue = getIntent().getDoubleExtra("userLatitude", 0.0);
        longValue = getIntent().getDoubleExtra("userLongtitude", 0.0);
        getDiscountAmount=getIntent().getIntExtra("DiscountPrice",0);
        getMaximumBillAmount=getIntent().getIntExtra("DiscountMaxAmount",0);
        discountName=getIntent().getStringExtra("DiscountName");
        typeOfDiscount=getIntent().getStringExtra("Typeofdiscount");
        ifPercentMaxAmountForDiscount=getIntent().getIntExtra("BillDiscountMaxAmount",0);
        customerID= HomePageAcitivity.saved_id;
        getPreference=getIntent().getStringExtra("Preference");
        oneTimeOrderNumber=getIntent().getStringExtra("orderNumber");
        getDiscountGivenBy=getIntent().getStringExtra("dicountGivenBy");



        Calendar cal = Calendar.getInstance();
        currentLocalTime = cal.getTime();

        getStoreLatitude = getIntent().getDoubleExtra("storeLatitude", 0);
        getStoreLongtitude = getIntent().getDoubleExtra("storeLongitude", 0);
        final SharedPreferences loginSharedPreferences = getSharedPreferences("SAVE", MODE_PRIVATE);
        if (loginSharedPreferences != null && !loginSharedPreferences.equals(""))
        {
            sharedPreferenceLat = loginSharedPreferences.getString("STORELATITUDE", "");
            sharedPreferenceLong = loginSharedPreferences.getString("STORELONGTITUDE", "");
        }
        if (sharedPreferenceLat != null && !sharedPreferenceLat.equals("")) {
            sharedPreferenceLatitude = Double.parseDouble(sharedPreferenceLat);
        }
        if (sharedPreferenceLong != null && !sharedPreferenceLong.equals("")) {
            sharedPreferenceLongtitude = Double.parseDouble(sharedPreferenceLong);
        }

        final SharedPreferences loginSharedPreferences1 = getSharedPreferences("DISTANCE", MODE_PRIVATE);
        getDistance = loginSharedPreferences1.getInt("Distance", 0);

        date = new SimpleDateFormat("HH:mm aa");
        DateFormat dateFormat = new SimpleDateFormat(Constant.DATE_FORMAT);
        currentDateAndTime = dateFormat.format(new Date());
        currentTime = date.format(currentLocalTime);
        metrozStoteTimingDataRef =CommonMethods.fetchFirebaseDatabaseReference("MetrozstoreTiming");
        storeTimingDataRef = CommonMethods.fetchFirebaseDatabaseReference("storeTimingMaintenance");
        userCurrentLocationDetails =CommonMethods.fetchFirebaseDatabaseReference("CustomerLoginDetails").child(String.valueOf(HomePageAcitivity.saved_id));
        Orderreference = CommonMethods.fetchFirebaseDatabaseReference(ORDER_DETAILS_FIREBASE_TABLE);
        viewCartRef = CommonMethods.fetchFirebaseDatabaseReference(VIEW_CART_FIREBASE_TABLE).
                child(customerID);
        autoLoadFunction();

        loadFunction();
        distanceFeeDataRef.child("OtherCategory").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getChildrenCount() > 0) {

                    MaintainFairDetails maintainFairDetails=dataSnapshot.getValue(MaintainFairDetails.class);
                    perKmDistanceFee = maintainFairDetails.getPerKmOtherCategory();
                    perkmDistanceFeeForDeliveryBoy=maintainFairDetails.getPerKmForDeliveryBoy();



                    int Radius = 6371;// radius of earth in Km

                    double lat1 = HomePageAcitivity.saved_Userlatitude;
                    double lat2 = sharedPreferenceLatitude;

                    double lon1 = HomePageAcitivity.saved_Userlongtitude;
                    double lon2 = sharedPreferenceLongtitude;

                    double dLat = Math.toRadians(lat2 - lat1);
                    double dLon = Math.toRadians(lon2 - lon1);
                    double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                            + Math.cos(Math.toRadians(lat1))
                            * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                            * Math.sin(dLon / 2);
                    double c = 2 * Math.asin(Math.sqrt(a));
                    double valueResult = Radius * c;

                    double km = valueResult / 1;

                    resultKiloMeterRoundOff = (int) Math.round(km);
                    roundOff = Math.round(km * 100.0) / 100.0;
                    totaldeliveryFee = resultKiloMeterRoundOff * perKmDistanceFee;
                    totalFeeFordeliveryBoy=resultKiloMeterRoundOff*perkmDistanceFeeForDeliveryBoy;

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        distanceFeeDataRef.child("DeliveryBoyCharges").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getChildrenCount() > 0) {

                    MaintainFairDetails maintainFairDetails=dataSnapshot.getValue(MaintainFairDetails.class);

                    perkmDistanceFeeForDeliveryBoy=maintainFairDetails.getPerKmForDeliveryBoy();



                    int Radius = 6371;// radius of earth in Km

                    double lat1 = HomePageAcitivity.saved_Userlatitude;
                    double lat2 = sharedPreferenceLatitude;

                    double lon1 = HomePageAcitivity.saved_Userlongtitude;
                    double lon2 = sharedPreferenceLongtitude;

                    double dLat = Math.toRadians(lat2 - lat1);
                    double dLon = Math.toRadians(lon2 - lon1);
                    double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                            + Math.cos(Math.toRadians(lat1))
                            * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                            * Math.sin(dLon / 2);
                    double c = 2 * Math.asin(Math.sqrt(a));
                    double valueResult = Radius * c;

                    double km = valueResult / 1;

                    resultKiloMeterRoundOff = (int) Math.round(km);
                    roundOff = Math.round(km * 100.0) / 100.0;
                    totalFeeFordeliveryBoy=resultKiloMeterRoundOff*perkmDistanceFeeForDeliveryBoy;

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        viewOffers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (viewOffers.getText().toString().equals("View Offers")) {
                    Intent intent = new Intent(PaymentActivity.this, DiscountActivity.class);
                    intent.putExtra("StoreName", storeNameFromAdapter);
                    intent.putExtra("StoreId", storeId);
                    intent.putExtra("categoryName", categoryName);
                    intent.putExtra("categoryId", categoryId);
                    intent.putExtra("pinCode", pinCode);
                    intent.putExtra("addressPref", addressPref);
                    intent.putExtra("FullAddress", getFullAdreesFromMap);
                    intent.putExtra("userLatitude", latValue);
                    intent.putExtra("userLongtitude", longValue);
                    intent.putExtra("deliveryType", deliverytType);
                    intent.putExtra("tips", String.valueOf(tipAmount));
                    intent.putExtra("finalBillTip", String.valueOf(finalBill_tip));
                    intent.putExtra("finalBillAmount", String.valueOf(finalBill));
                    intent.putExtra("instructionString", instructionString);
                    intent.putExtra("storeAddress", storeAddress);
                    intent.putExtra("shippingAddress", shippingAddress);
                    intent.putExtra("customerName", customerName);
                    intent.putExtra("customerMobilenumber", customerMobilenumber);
                    intent.putExtra("customerPinCode", customerPinCode);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }else if (viewOffers.getText().toString().equals("Remove")) {
                    typeOfDiscount = null;
                    getDiscountAmount = 0;
                    getMaximumBillAmount = 0;
                    discountName = "-";
                    getPreference = "";
                    viewOffers.setText("View Offers");
                    autoLoadFunction();
                }
            }
        });

        backToScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PaymentActivity.this, ViewCartActivity.class);
                intent.putExtra("deliveryType", deliverytType);
                intent.putExtra("tips", String.valueOf(tipAmount));
                intent.putExtra("finalBillTip", String.valueOf(finalBill_tip));
                intent.putExtra("finalBillAmount", String.valueOf(finalBill));
                intent.putExtra("instructionString", instructionString);
                intent.putExtra("storeAddress", storeAddress);
                intent.putExtra("shippingAddress",shippingAddress);
                intent.putExtra("customerName",customerName);
                intent.putExtra("customerMobilenumber",customerMobilenumber);
                intent.putExtra("customerPinCode",customerPinCode);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });

        purchaseLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemDetailList.size() == 0) {

                    new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE)
                            .setTitleText("Error")
                            .setContentText("No items available in the cart.")
                            .show();
                    return;
                } else
                {
                    metrozStoteTimingDataRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.getChildrenCount()>0) {
                                MetrozStoreTime metrozStoreTime = dataSnapshot.getValue(MetrozStoreTime.class);

                                metrozStartTime = metrozStoreTime.getShopStartTime();
                                metrozStopTime = metrozStoreTime.getShopEndTime();
                            }
                            storeTimingDataRef.child(String.valueOf(storeId)).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (checkAsync) {

                                        if (dataSnapshot.getChildrenCount() > 0) {

                                            StoreTimings storeTimings = dataSnapshot.getValue(StoreTimings.class);
                                            try {
                                                //if result returns 1 => shop starts time is after metroz time
                                                //if result returns -1 => shops end time is before metroz end time
                                                //if result returns 0 => shop start,stop and metroz starts and stop time are same

                                                //Starting time of shop is after metroz time && ending time of shop is before metroz time

                                                if ((sdf.parse(currentTime).compareTo(sdf.parse(metrozStartTime)) == 1) && !(sdf.parse(currentTime).compareTo(sdf.parse(metrozStopTime)) == 1))
                                                {
                                                    if ((sdf.parse(storeTimings.getShopStartTime()).compareTo(sdf.parse(metrozStartTime)) == 1 &&
                                                            (sdf.parse(storeTimings.getShopEndTime()).compareTo(sdf.parse(metrozStopTime)) == -1))
                                                            ||  // Starting time of shop is equal to metroz &&  ending time of shop is before metroz time
                                                            (sdf.parse(storeTimings.getShopStartTime()).compareTo(sdf.parse(metrozStartTime)) == 0 &&
                                                                    (sdf.parse(storeTimings.getShopEndTime()).compareTo(sdf.parse(metrozStopTime)) == -1))
                                                            || //Starting time of shop is after metroz time && ending time of metroz is equal to metroz timing
                                                            (sdf.parse(storeTimings.getShopStartTime()).compareTo(sdf.parse(metrozStartTime)) == 1 &&
                                                                    sdf.parse(storeTimings.getShopEndTime()).compareTo(sdf.parse(metrozStopTime)) == 0)
                                                            ||  //start and end time is equal to metroz timings
                                                            (sdf.parse(storeTimings.getShopStartTime()).compareTo(sdf.parse(metrozStartTime)) == 0 &&
                                                                    sdf.parse(storeTimings.getShopEndTime()).compareTo(sdf.parse(metrozStopTime)) == 0)) {


                                                        //avail stores list
                                                        if (storeTimings.getStoreStatus().equalsIgnoreCase(""))
                                                        {
                                                            if ((sdf.parse(currentTime).compareTo(sdf.parse(storeTimings.getShopStartTime())) == 1) && !(sdf.parse(currentTime).compareTo(sdf.parse(storeTimings.getShopEndTime())) == 1)) {
                                                                resultChecking();

                                                            } else if ((sdf.parse(currentTime).compareTo(sdf.parse(storeTimings.getShopEndTime())) == 1) || (sdf.parse(currentTime).compareTo(sdf.parse(storeTimings.getShopStartTime())) == -1)) {
                                                                new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE)
                                                                        .setTitleText("Error")
                                                                        .setContentText("Closed,currently not accepting orders.")
                                                                        .show();
                                                            }
                                                        } else {
                                                            if (storeTimings.getStoreStatus().equalsIgnoreCase("Opened")) {
                                                                resultChecking();

                                                            }
                                                            if (storeTimings.getStoreStatus().equalsIgnoreCase("Closed")) {
                                                                new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE)
                                                                        .setTitleText("Error")
                                                                        .setContentText("Closed,currently not accepting orders.")
                                                                        .show();
                                                            }
                                                        }
                                                    }
                                                }else {
                                                    new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE)
                                                            .setTitleText("Error")
                                                            .setContentText("Closed,currently not accepting orders.")
                                                            .show();
                                                }
                                            } catch (ParseException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });


                }
            }
        });

    }
    private void startpayment() throws JSONException, RazorpayException {

        razorpay = new RazorpayClient(RAZORPAY_KEY_ID, RAZORPAY_SECRAT_KEY);
        JSONObject options = new JSONObject();

        options.put("amount", ((tipsAmountInt+giftWrapAmount-getDiscountAmount) * 100));

        options.put("currency", "INR");
        options.put("receipt",generateString(10));
        Order order = razorpay.Orders.create(options);
        jsonObject = new JSONObject(String.valueOf(order));
        resultOrderId = jsonObject.getString("id");
        receiptNumber = jsonObject.getString("receipt");
        checkOutFunction(resultOrderId);
    }
    private void checkOutFunction(String orderId) throws JSONException {

        final Activity activity = this;
        Checkout checkout = new Checkout();
        checkout.setKeyID(RAZORPAY_KEY_ID);
        checkout.setImage(R.mipmap.ic_launcher);
        JSONObject options = new JSONObject();
        options.put("payment_capture", true);
        options.put("order_id", orderId);
        JSONObject preFill = new JSONObject();
        //to set predefined mail and contact
        preFill.put("email", HomePageAcitivity.saved_userName);
        preFill.put("contact", HomePageAcitivity.saved_customerPhonenumber);
        options.put("prefill", preFill);

        checkout.open(activity, options);

    }
    public static String generateOTP() {
        int randomPin = (int) (Math.random() * 900000) + 100000;
        String otp = String.valueOf(randomPin);
        return otp;
    }
    protected void onStart() {
        super.onStart();

        Orderreference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                maxid = dataSnapshot.getChildrenCount();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        viewCartRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.getChildrenCount() > 0) {
                    giftWrapItemList.clear();
                    itemDetailList.clear();
                    finalBillAmount = 0;
                    tipsAmountInt = 0;
                    name = new ArrayList<>();
                    id = new ArrayList<>();
                    name.clear();
                    id.clear();
                    for (DataSnapshot viewCartsnap : dataSnapshot.getChildren()) {
                        itemDetails = viewCartsnap.getValue(ItemDetails.class);

                        if (itemDetails.getCategoryName().equalsIgnoreCase("GIFTS AND LIFESTYLES")) {
                            if (itemDetails.getGiftWrapOption() != null) {
                                if (itemDetails.getGiftWrapOption().equals("Yes")) {
                                    giftWrapItemList.add(itemDetails);
                                }
                            }
                        }
                        if (giftWrapItemList.size() > 0) {

                            giftWrapText.setVisibility(View.VISIBLE);
                            giftWrapText.startAnimation(animation);
                            if (!testPay.equals("Failed")) {
                                RelativeLayout my_layout = findViewById(R.id.tetef);

                                name.clear();
                                id.clear();

                                for (int i = 0; i < giftWrapItemList.size(); i++) {
                                    //name.add("C" + (i + 1));
                                    if (giftWrapItemList != null) {
                                        if (giftWrapItemList.get(i).getGiftAmount() == 0) {
                                            name.add(giftWrapItemList.get(i).getItemName() + " (Free Wrapping)");
                                        } else {
                                            name.add(giftWrapItemList.get(i).getItemName() + " (Wrapping Charge ₹" + giftWrapItemList.get(i).getGiftAmount() + ")");
                                        }
                                        id.add(i + 1);
                                    }
                                }

                                for (int i = 0; i < name.size(); i++) {
                                    RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                                    if (i == 0) {
                                        params.topMargin = 50;
                                    }
                                    CheckBox checkBox = new CheckBox(PaymentActivity.this);
                                    checkBox.setId(id.get(i));
                                    checkBox.setText(name.get(i));

                                    //checkBox.setTextColor(Color.BLUE);
                                    checkBox.setTextAppearance(PaymentActivity.this, R.style.CustomActivityTheme);
                                    // checkBox.setTextColor(getResources().getColor(R.color.grey));
                                    checkBox.setTypeface(ResourcesCompat.getFont(PaymentActivity.this, R.font.coustard));
                                    checkBox.setChecked(false);

                                    if (i != 0) {
                                        params.addRule(RelativeLayout.BELOW, id.get(i - 1));
                                    }


                                    checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                                            if (b) {
                                                int id = checkBox.getId();
                                                giftWrapAmount = giftWrapAmount + giftWrapItemList.get(id - 1).getGiftAmount();
                                                giftWappingItemList.add(giftWrapItemList.get(id - 1).getItemName());
                                                giftText.setText("Gift Wrap");
                                                giftAmount.setText(" ₹" + giftWrapAmount);
                                                if (discountAppliedOrNot.equals("Yes"))
                                                {
                                                    toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
                                                    totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
                                                }
                                                else
                                                {
                                                    toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
                                                    totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
                                                }
                                            } else {
                                                int id = checkBox.getId();
                                                giftWrapAmount = giftWrapAmount - giftWrapItemList.get(id - 1).getGiftAmount();
                                                giftWappingItemList.remove(giftWrapItemList.get(id - 1).getItemName());
                                                giftText.setText("Gift Wrap");
                                                giftAmount.setText(" ₹" + giftWrapAmount);
                                                if (discountAppliedOrNot.equals("Yes"))
                                                {
                                                    toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
                                                    totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
                                                }
                                                else
                                                {
                                                    toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
                                                    totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
                                                }
                                            }
                                        }
                                    });
                                    checkBox.setLayoutParams(params);
                                    my_layout.addView(checkBox, params);
                                }
                            }
                        }
                        finalBillAmount = finalBillAmount + (itemDetails.getTotalItemQtyPrice());
                        tipsAmountInt = finalBillAmount;
                        itemDetailList.add(itemDetails);
                    }
                    orderDetails.setItemDetailList(itemDetailList);
                    orderDetails.setStoreName(itemDetails.getStoreName());
                    orderDetails.setStorePincode(itemDetails.getStorePincode());
                    orderDetails.setStoreAddress(itemDetails.getStoreAdress());
                    orderDetails.setGiftWrappingItemName(giftWappingItemList);
                    orderDetails.setTotalAmount(Integer.parseInt(String.valueOf(finalBillAmount)));

                    if (itemDetailList != null && itemDetailList.size() > 0) {
                        storeId = itemDetailList.get(0).getSellerId();
                    }
                    if ("".equalsIgnoreCase(tipAmount) || tipAmount == null) {
                        temp = 0;
                    } else {
                        temp = Integer.parseInt(tipAmount);
                    }
                    tipsAmountInt = finalBillAmount + temp;
                }


                PaymentAdapter viewCartAdapter = new PaymentAdapter(PaymentActivity.this, itemDetailList);
                purchaseListView.setAdapter(viewCartAdapter);
                viewCartAdapter.notifyDataSetChanged();

                if (viewCartAdapter != null) {
                    int totalHeight = 0;

                    for (int i = 0; i < viewCartAdapter.getCount(); i++) {
                        View listItem = viewCartAdapter.getView(i, null, purchaseListView);
                        listItem.measure(0, 0);
                        totalHeight += listItem.getMeasuredHeight();
                    }

                    ViewGroup.LayoutParams params = purchaseListView.getLayoutParams();
                    params.height = totalHeight + (purchaseListView.getDividerHeight() * (viewCartAdapter.getCount() - 1));
                    purchaseListView.setLayoutParams(params);
                    purchaseListView.requestLayout();
                    purchaseListView.setAdapter(viewCartAdapter);
                    viewCartAdapter.notifyDataSetChanged();


                    totalItemValue.setText(" ₹" + String.valueOf(finalBill));
                    tipValue.setText(" ₹" + String.valueOf(temp));
                    if(discountAppliedOrNot.equals("Yes"))

                    {
                        totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
                        toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
                    }
                    else {
                        totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
                        toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public void onPaymentSuccess(String s, PaymentData paymentData)
    {

        pDialog = new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#06519A"));
        pDialog.setTitleText("Loading ...");
        pDialog.setCancelable(false);
        pDialog.show();
        loadFunction();
        if (checkIntent == true)
        {
            orderDetails.setPaymentId(paymentData.getPaymentId());
            try
            {
                razorpay = new RazorpayClient(RAZORPAY_KEY_ID, RAZORPAY_SECRAT_KEY);
                payment = razorpay.Payments.fetch(paymentData.getPaymentId());
                jsonObject = new JSONObject(String.valueOf(payment));
                paymentType = jsonObject.getString("method");
                amount = jsonObject.getString("amount");
            }
            catch (RazorpayException | JSONException e)
            {
            }
            orderDetails.setPaymentType(paymentType);
            orderDetails.setOrderIdfromPaymentGateway(resultOrderId);
            orderDetails.setOrderStatus("Order Placed");
            orderDetails.setOrderTime(DateUtils.fetchCurrentTime());
            orderDetails.setOrderCreateDate(DateUtils.fetchCurrentDateAndTime());
            orderDetails.setTotalAmount(finalBillAmount);
            if (discountAppliedOrNot.equals("Yes"))
            {
                orderDetails.setDiscountName(String.valueOf(discountName));
                orderDetails.setDiscountAmount(getDiscountAmount);
            }else
            {
                orderDetails.setDiscountName("");
                orderDetails.setDiscountAmount(0);
            }
            orderDetails.setAssignedTo("");
            orderDetails.setTipAmount(temp);
            orderDetails.setDeliverOtp(generateOTP());
            orderDetails.setCategoryTypeId("1");
            orderDetails.setFormattedDate(DateUtils.fetchFormatedCurrentDate());
            orderDetails.setPaymentamount(tipsAmountInt+giftWrapAmount-getDiscountAmount);
            orderDetails.setPaymentDate(DateUtils.fetchCurrentDate());
            orderDetails.setCustomerName(HomePageAcitivity.saved_customer);
            orderDetails.setCustomerId(saved_id);
            orderDetails.setTotalDistanceTraveled(resultKiloMeterRoundOff);
            orderDetails.setDeliveryFee(totaldeliveryFee);
            orderDetails.setTotalFeeForDeliveryBoy(totalFeeFordeliveryBoy);
            orderDetails.setDeliveryType(deliverytType);
            orderDetails.setGiftWrapCharge(giftWrapAmount);
            orderDetails.setStoreAddress(storeAddress);
            orderDetails.setNotificationStatus("false");
            orderDetails.setNotificationStatusForCustomer("false");
            orderDetails.setNotificationStatusForSeller("false");
            orderDetails.setInstructionsToDeliveryBoy(instructionString);
            orderDetails.setDiscountGivenBy(getDiscountGivenBy);
            orderDetails.setSellerLatitude(sharedPreferenceLatitude);
            orderDetails.setSellerLongtitude(sharedPreferenceLongtitude);
            String myTime = DateUtils.fetchCurrentTime();

            SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
            Date d = null;

            try {
                d = df.parse(myTime);
                Calendar cal = Calendar.getInstance();
                cal.setTime(d);
                cal.add(Calendar.SECOND, 60);
                String newTime = df.format(cal.getTime());
                orderDetails.setTimerForCancelDelivery(newTime);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            onTransaction(Orderreference);

            if (getPreference!=null && !getPreference.equals("")) {
                if (getPreference.equals("1")) {
                    if (!((Activity) PaymentActivity.this).isFinishing()) {
                        DatabaseReference orderDetailsRef =CommonMethods.fetchFirebaseDatabaseReference("OneTimeDiscount").child(getPreference);
                        orderDetailsRef.child("usedTag").setValue("true");
                    }
                }
            }

        }
    }

    @Override
    public void onPaymentError(int i, String s, PaymentData paymentData) {
        testPay="Failed";
        if (discountAppliedOrNot.equals("Yes"))
        {
            toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
            totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount-getDiscountAmount));
        }
        else
        {
            toPayValue.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
            totalPurchaseAmount.setText(" ₹" + String.valueOf(tipsAmountInt + giftWrapAmount));
        }


        if (!((Activity) PaymentActivity.this).isFinishing ()) {
            SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE);
            sweetAlertDialog.setCancelable(false);
            sweetAlertDialog.setTitleText("Payment cancelled").setContentText("Please try again!").show();

        }
    }
    public void resultChecking() {
        if (!CommonMethods.getConnectivityStatusString(getApplicationContext()).equals("No internet is available")) {
            userCurrentLocationDetails.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getChildrenCount() > 0) {
                        userCurrentLocation = dataSnapshot.getValue(CustomerDetails.class);

                        int Radius = 6371;// radius of earth in Km
                        double lat1 = userCurrentLocation.getUserLatitude();
                        double lat2 = sharedPreferenceLatitude;
                        double lon1 = userCurrentLocation.getUserLongtitude();
                        double lon2 = sharedPreferenceLongtitude;
                        double dLat = Math.toRadians(lat2 - lat1);
                        double dLon = Math.toRadians(lon2 - lon1);
                        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                                + Math.cos(Math.toRadians(lat1))
                                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                                * Math.sin(dLon / 2);
                        double c = 2 * Math.asin(Math.sqrt(a));
                        double valueResult = Radius * c;
                        double km = valueResult / 1;
                        int resultKiloMeterRoundOff = (int) Math.round(km);
                        roundOff = Math.round(km * 100.0) / 100.0;
                        if (resultKiloMeterRoundOff <= getDistance) {

                            if (userCurrentLocation.getCurrentPincode() == null || userCurrentLocation.getCurrentPincode().equals("")) {

                                SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE);
                                sweetAlertDialog.setCancelable(false);
                                sweetAlertDialog.setTitleText("Delivery is not available in this location").show();
                            } else if (userCurrentLocation.getCurrentPincode() != null && !userCurrentLocation.getCurrentPincode().equals("") &&
                                    !TextUtils.validPinCode(userCurrentLocation.getCurrentPincode())) {

                                SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE);
                                sweetAlertDialog.setCancelable(false);
                                sweetAlertDialog.setTitleText("Delivery is not available in this location").show();


                            } else if (userCurrentLocation.getCurrentPincode() != null && !userCurrentLocation.getCurrentPincode().equals("") &&
                                    TextUtils.validPinCode(userCurrentLocation.getCurrentPincode())) {

                                if ((saved_id != null && !"".equals(saved_id))) {


                                    if (!((Activity) PaymentActivity.this).isFinishing()) {
                                        Checkout.preload(getApplicationContext());
                                        new backGroundClass().execute();
                                    }
                                } else {
                                    Toast.makeText(PaymentActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(PaymentActivity.this, HomePageAcitivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                }
                            } else {
                                if (!((Activity) PaymentActivity.this).isFinishing()) {
                                    Toast.makeText(PaymentActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(PaymentActivity.this, HomePageAcitivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                }
                            }
                        } else {
                            SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE);
                            sweetAlertDialog.setCancelable(false);
                            sweetAlertDialog.setTitleText("Delivery is not available in this location").show();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } else {
            new SweetAlertDialog(PaymentActivity.this, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("Error")
                    .setContentText("No Network Connection")
                    .show();

        }
    }


    private class backGroundClass extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                startpayment();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (RazorpayException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public void loadFunction() {
        userCurrentLocationDetails.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getChildrenCount() > 0) {

                    userCurrentLocation = dataSnapshot.getValue(CustomerDetails.class);



                    if("2".equalsIgnoreCase(addressPref))  {
                        viewAddress.setText(shippingAddress);
                        orderDetails.setShippingaddress(shippingAddress);
                        orderDetails.setFullName(customerName);
                        orderDetails.setShippingPincode(customerPinCode);
                        orderDetails.setCustomerPhoneNumber(customerMobilenumber);

                    }else  if("1".equalsIgnoreCase(addressPref)) {
                        viewAddress.setText(userCurrentLocation.getCurrentAddress());
                        orderDetails.setFullName(userCurrentLocation.getFullName());
                        orderDetails.setCustomerPhoneNumber(HomePageAcitivity.saved_customerPhonenumber);
                        orderDetails.setShippingPincode(userCurrentLocation.getCurrentPincode());
                        orderDetails.setShippingaddress(userCurrentLocation.getCurrentAddress());

                    }
                    checkIntent = true;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public void onBackPressed() {

        Intent intent = new Intent(PaymentActivity.this, HomePageAcitivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
    public void checkGPSConnection(Context context) {

        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        boolean statusOfGPS = manager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        if (!statusOfGPS)
            Toast.makeText(context.getApplicationContext(), "GPS is disable!", Toast.LENGTH_LONG).show();
    }
    public void autoLoadFunction()
    {
        if (typeOfDiscount!=null)
        {
            viewOffers.setText("Remove");
            if (typeOfDiscount.equals("Price"))
            {
                if ((Integer.parseInt(finalBill)>=getMaximumBillAmount)) {
                    deductionAmountTextView.setText("- ₹"+String.valueOf(getDiscountAmount));
                    offerName.setText(discountName);
                    discountAppliedOrNot="Yes";

                    final AlertDialog.Builder builder = new AlertDialog.Builder(PaymentActivity.this,R.style.CustomAlertDialog);
                    ViewGroup viewGroup = findViewById(android.R.id.content);
                    View dialogView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.customlayout, viewGroup, false);
                    builder.setView(dialogView);
                    final AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            alertDialog.dismiss();
                        }
                    }, 2000);
                } else {
                    offerName.setText("Offer is not applicable");
                    discountAppliedOrNot="No";
                    offerName.setCompoundDrawablesWithIntrinsicBounds ( R.drawable.ic_crossline_01, 0, 0, 0 );
                }
            } else if (typeOfDiscount.equals("Percent"))
            {
                if ((Integer.parseInt(finalBill)>=getMaximumBillAmount))
                {

                    discountAmountCalculation=(getDiscountAmount*Integer.parseInt(finalBill))/100;

                    if (ifPercentMaxAmountForDiscount<=discountAmountCalculation)
                    {
                        getDiscountAmount=discountAmountCalculation;
                        deductionAmountTextView.setText("- ₹"+String.valueOf(getDiscountAmount));
                    }
                    else
                    {
                        getDiscountAmount=ifPercentMaxAmountForDiscount;
                        deductionAmountTextView.setText("- ₹"+String.valueOf(getDiscountAmount));
                    }
                    offerName.setText(discountName);
                    discountAppliedOrNot="Yes";

                    final AlertDialog.Builder builder = new AlertDialog.Builder(PaymentActivity.this,R.style.CustomAlertDialog);
                    ViewGroup viewGroup = findViewById(android.R.id.content);
                    View dialogView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.customlayout, viewGroup, false);
                    builder.setView(dialogView);
                    final AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            alertDialog.dismiss();
                        }
                    }, 2000);

                } else {
                    offerName.setText("Offer is not applicable");
                    discountAppliedOrNot="No";
                    offerName.setCompoundDrawablesWithIntrinsicBounds ( R.drawable.ic_crossline_01, 0, 0, 0 );
                }
            }
        }
        else
        {
            deductionAmountTextView.setText("- ₹"+String.valueOf(getDiscountAmount));
            onStart();
        }

    }

    private void onTransaction(DatabaseReference postRef) {

        postRef.runTransaction(new Transaction.Handler() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public Transaction.Result doTransaction(MutableData mutableData) {
                increamentId = Math.toIntExact(mutableData.getChildrenCount());
                if (increamentId == null) {
                    orderDetails.setOrderId(String.valueOf(1));
                    mutableData.child(String.valueOf(1)).setValue(orderDetails);
                    return Transaction.success(mutableData);
                }
                else
                {
                    increamentId=increamentId+1;
                    orderDetails.setOrderId(String.valueOf(increamentId));
                    mutableData.child(String.valueOf(increamentId)).setValue(orderDetails);
                    return Transaction.success(mutableData);
                }
            }
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onComplete(DatabaseError databaseError, boolean b, DataSnapshot dataSnapshot)
            {
                viewCartRef.removeValue();
                Intent intent = new Intent(PaymentActivity.this, ViewOrderActivity.class);
                intent.putExtra("OrderidDetails", String.valueOf(increamentId));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }
    public static String generateString(int length) {
        char[] chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789!@#$%^&*".toCharArray ();
        StringBuilder stringBuilder = new StringBuilder ();
        Random random = new Random ();

        for ( int i = 0; i < length; i++ ) {
            char c = chars[random.nextInt ( chars.length )];
            stringBuilder.append ( c );
        }
        return stringBuilder.toString ();
    }
}